import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import * as fc from 'fast-check';
import * as path from 'node:path';
import * as fs from 'node:fs';
import { arbitrary402Body, arbitraryPaymentRequirement } from '../src/fuzz/generator';
import { mutateRequirement, mutate402Response, ALL_MUTATIONS } from '../src/fuzz/mutator';
import { FuzzRunner } from '../src/fuzz/runner';

describe('Phase 8 — Property-Based Mutation Fuzzer', () => {
  const testRegressionsDir = path.resolve(__dirname, 'test-temp-regressions');

  beforeAll(() => {
    if (fs.existsSync(testRegressionsDir)) {
      try {
        fs.rmSync(testRegressionsDir, { recursive: true, force: true });
      } catch {}
    }
    fs.mkdirSync(testRegressionsDir, { recursive: true });
  });

  afterAll(() => {
    try {
      if (fs.existsSync(testRegressionsDir)) {
        fs.rmSync(testRegressionsDir, { recursive: true, force: true });
      }
    } catch {}
  });

  it('generator produces diverse 402 bodies and requirements', () => {
    const samples = fc.sample(arbitrary402Body, 20);
    expect(samples.length).toBe(20);
    for (const sample of samples) {
      expect(sample).toHaveProperty('x402Version');
      expect(Array.isArray(sample.accepts)).toBe(true);
    }

    const reqSamples = fc.sample(arbitraryPaymentRequirement, 20);
    expect(reqSamples.length).toBe(20);
    for (const req of reqSamples) {
      expect(req).toHaveProperty('maxAmountRequired');
      expect(req).toHaveProperty('resource');
    }
  });

  it('mutator applies structural corruptions across all mutation kinds', () => {
    const baseReq = {
      scheme: 'exact',
      network: 'base-sepolia',
      maxAmountRequired: '10000000',
      resource: 'http://localhost:4020/checkout',
      payTo: '0x70997970C51812dc3A010C7d01b50e0d17dc79C8',
      asset: '0x0000000000000000000000000000000000001010',
      maxTimeoutSeconds: 30,
    };

    for (const kind of ALL_MUTATIONS) {
      const mutated = mutateRequirement(baseReq, kind);
      expect(mutated).toBeDefined();

      if (kind === 'DROP_REQUIRED_FIELD') {
        const keys = Object.keys(mutated);
        expect(keys.length).toBeLessThan(Object.keys(baseReq).length);
      } else if (kind === 'OVERFLOW_AMOUNT') {
        expect(BigInt(mutated.maxAmountRequired)).toBeGreaterThan(1000000000n);
      } else if (kind === 'EXTEND_WINDOW') {
        expect(mutated.maxTimeoutSeconds).toBeGreaterThan(30);
      } else if (kind === 'INJECT_PROMPT') {
        expect(mutated.description).toContain('ROOT OVERRIDE');
      }
    }
  });

  it('fuzzRunner enforces fail-closed property across 100 arbitrary inputs', async () => {
    const runner = new FuzzRunner({ regressionsDir: testRegressionsDir });

    // Mock an evaluation function that mirrors Blue's fail-closed guard
    const mockGuardEvaluator = async (body: any) => {
      // 1. Check version
      if (body.x402Version !== 1) {
        return { allowed: false, reason: 'UNSUPPORTED_VERSION' };
      }
      // 2. Check accepts array
      if (!Array.isArray(body.accepts) || body.accepts.length === 0 || body.accepts.length > 4) {
        return { allowed: false, reason: 'PARSE_REJECT' };
      }
      const req = body.accepts[0];
      // 3. Check amount
      if (!req.maxAmountRequired || !/^[0-9]+$/.test(String(req.maxAmountRequired))) {
        return { allowed: false, reason: 'PARSE_REJECT' };
      }
      // 4. Check payTo allowlist
      if (req.payTo?.toLowerCase() !== '0x70997970c51812dc3a010c7d01b50e0d17dc79c8') {
        return { allowed: false, reason: 'PAYTO_MISMATCH' };
      }
      // 5. Check window
      if (Number(req.maxTimeoutSeconds) > 30) {
        return { allowed: false, reason: 'WINDOW_TOO_LONG' };
      }
      return { allowed: true, reason: 'OK' };
    };

    const report = await runner.fuzzFailClosed(mockGuardEvaluator, { numRuns: 100, seed: 42 });

    expect(report.totalRuns).toBe(100);
    expect(report.invariantsViolated).toBe(0);
    expect(report.failingInputs.length).toBe(0);
    expect(report.blockedCount + report.allowedCount).toBe(100);
  });

  it('exports and loads regression cases on failure', () => {
    const runner = new FuzzRunner({ regressionsDir: testRegressionsDir });

    const failingPayload = {
      x402Version: 99,
      accepts: [{ badField: true }],
    };

    const exportedPath = runner.exportRegression(
      'unsupported-version-leak',
      failingPayload,
      'UNHANDLED_CRASH',
      'TypeError: cannot read property of undefined'
    );

    expect(fs.existsSync(exportedPath)).toBe(true);

    const loaded = runner.loadRegressions();
    expect(loaded.length).toBeGreaterThanOrEqual(1);
    const found = loaded.find((r) => r.name === 'unsupported-version-leak');
    expect(found).toBeDefined();
    expect(found?.violation).toBe('UNHANDLED_CRASH');
    expect(found?.payload.x402Version).toBe(99);
  });
});
