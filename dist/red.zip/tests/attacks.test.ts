import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import * as http from 'node:http';
import * as path from 'node:path';
import * as fs from 'node:fs';
import { createChainServer } from '../../blue/src/chain/server';
import { createCollectorServer } from '../../blue/src/collector/server';
import { createAgentServer } from '../../blue/src/agent/server';
import { createMerchantServer } from '../src/merchant/server';
import { createFacilitatorServer } from '../src/facilitator/server';
import { AttackOrchestrator } from '../src/orchestrator/runner';
import { KillSwitch } from '../src/orchestrator/kill-switch';
import { DatabaseAdapter } from '../../blue/src/storage/db';

const TEST_DIR = path.resolve(__dirname, 'test-temp-attacks');

describe('Phase 6 — Red Attack Suite & Orchestrator Matrix', () => {
  let chainServer: http.Server;
  let collectorServer: http.Server;
  let merchantServer: http.Server;
  let facilitatorServer: http.Server;
  let agentServer: http.Server;

  let chainDb: DatabaseAdapter;
  let collectorDb: DatabaseAdapter;
  let agentV1Guard: any;

  let chainUrl: string;
  let collectorUrl: string;
  let merchantUrl: string;
  let facilitatorUrl: string;
  let agentUrl: string;

  let orchestrator: AttackOrchestrator;
  let customKillSwitch: KillSwitch;

  beforeAll(async () => {
    if (fs.existsSync(TEST_DIR)) {
      fs.rmSync(TEST_DIR, { recursive: true, force: true });
    }
    fs.mkdirSync(TEST_DIR, { recursive: true });

    // 1. Start Blue Chain
    const chain = createChainServer({
      port: 0,
      dbPath: path.resolve(TEST_DIR, 'chain.db'),
    });
    chainDb = (chain as any).db;
    await new Promise<void>((res) => {
      chainServer = chain.app.listen(0, () => {
        const addr: any = chainServer.address();
        chainUrl = `http://localhost:${addr.port}`;
        res();
      });
    });

    // 2. Start Blue Collector
    const collector = createCollectorServer({
      port: 0,
      dbPath: path.resolve(TEST_DIR, 'collector.db'),
    });
    collectorDb = collector.db;
    await new Promise<void>((res) => {
      collectorServer = collector.app.listen(0, () => {
        const addr: any = collectorServer.address();
        collectorUrl = `http://localhost:${addr.port}`;
        res();
      });
    });

    // 3. Start Red Facilitator
    const facilitator = createFacilitatorServer({
      port: 0,
      chainUrl,
    });
    await new Promise<void>((res) => {
      facilitatorServer = facilitator.app.listen(0, () => {
        const addr: any = facilitatorServer.address();
        facilitatorUrl = `http://localhost:${addr.port}`;
        res();
      });
    });

    // 4. Start Red Merchant
    const merchant = createMerchantServer({
      port: 0,
      facilitatorUrl,
      chainUrl,
    });
    await new Promise<void>((res) => {
      merchantServer = merchant.app.listen(0, () => {
        const addr: any = merchantServer.address();
        merchantUrl = `http://localhost:${addr.port}`;
        res();
      });
    });

    // 5. Start Blue Agent
    const agent = createAgentServer({
      port: 0,
      merchantUrl,
      chainUrl,
      collectorUrl,
      keysDir: path.resolve(TEST_DIR, 'keys'),
      budgetDbPath: path.resolve(TEST_DIR, 'budget.db'),
      auditDbPath: path.resolve(TEST_DIR, 'audit.jsonl'),
    });
    agentV1Guard = agent.v1Guard;
    await new Promise<void>((res) => {
      agentServer = agent.app.listen(0, () => {
        const addr: any = agentServer.address();
        agentUrl = `http://localhost:${addr.port}`;
        res();
      });
    });

    // Fund the agent account with 1,000 TUSD (1,000,000,000 atomic)
    await fetch(`${chainUrl}/fund`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        address: agent.rawAccount.address,
        amount_atomic: '1000000000',
      }),
    });

    customKillSwitch = new KillSwitch();
    orchestrator = new AttackOrchestrator({
      merchantUrl,
      facilitatorUrl,
      chainUrl,
      agentUrl,
      collectorUrl,
      killSwitch: customKillSwitch,
    });
  });

  afterAll(async () => {
    if (agentV1Guard) agentV1Guard.close();
    if (chainDb) chainDb.close();
    if (collectorDb) collectorDb.close();

    await Promise.all([
      new Promise<void>((res) => agentServer?.close(() => res())),
      new Promise<void>((res) => merchantServer?.close(() => res())),
      new Promise<void>((res) => facilitatorServer?.close(() => res())),
      new Promise<void>((res) => collectorServer?.close(() => res())),
      new Promise<void>((res) => chainServer?.close(() => res())),
    ]);

    if (fs.existsSync(TEST_DIR)) {
      fs.rmSync(TEST_DIR, { recursive: true, force: true });
    }
  });

  it('respects real-time Kill Switch and halts execution immediately', async () => {
    customKillSwitch.kill('Emergency test stop');
    await expect(
      orchestrator.runAttack({
        attackId: 'A1',
        target: 'BLUE_V1',
        seed: 12345,
      })
    ).rejects.toThrow(/Kill Switch/i);
    customKillSwitch.reset();
  });

  describe('A1: Payee Swap', () => {
    it('succeeds against NAIVE mode (stealing funds to attacker wallet)', async () => {
      const res = await orchestrator.runAttack({
        attackId: 'A1',
        target: 'NAIVE',
        seed: 101,
      });

      expect(res.decision).toBe('ALLOW');
      expect(res.attackerWon).toBe(true);
      expect(BigInt(res.funds_lost_atomic)).toBeGreaterThan(0n);
    });

    it('succeeds against BLUE_V0 mode (V0 lacks payee verification)', async () => {
      const res = await orchestrator.runAttack({
        attackId: 'A1',
        target: 'BLUE_V0',
        seed: 102,
      });

      expect(res.decision).toBe('ALLOW');
      expect(res.attackerWon).toBe(true);
      expect(BigInt(res.funds_lost_atomic)).toBeGreaterThan(0n);
    });

    it('is completely blocked by BLUE_V1 at Layer L2 with PAYTO_MISMATCH (0 funds lost)', async () => {
      const res = await orchestrator.runAttack({
        attackId: 'A1',
        target: 'BLUE_V1',
        seed: 103,
      });

      expect(res.decision).toBe('BLOCK');
      expect(res.reason).toBe('PAYTO_MISMATCH');
      expect(res.layer).toBe('L2');
      expect(res.attackerWon).toBe(false);
      expect(res.funds_lost_atomic).toBe('0');
    });
  });

  describe('A4: Wallet Drain', () => {
    it('is blocked by BLUE_V0 via max amount cap', async () => {
      const res = await orchestrator.runAttack({
        attackId: 'A4',
        target: 'BLUE_V0',
        seed: 201,
      });

      expect(res.decision).toBe('BLOCK');
      expect(res.funds_lost_atomic).toBe('0');
    });

    it('is blocked by BLUE_V1 at Layer L3 with PRICE_OUT_OF_BAND', async () => {
      const res = await orchestrator.runAttack({
        attackId: 'A4',
        target: 'BLUE_V1',
        seed: 202,
      });

      expect(res.decision).toBe('BLOCK');
      expect(res.reason).toBe('PRICE_OUT_OF_BAND');
      expect(res.layer).toBe('L3');
      expect(res.funds_lost_atomic).toBe('0');
    });
  });

  describe('A8: Quote Mutation Between Approval and Signing', () => {
    it('succeeds against NAIVE and drains funds', async () => {
      const res = await orchestrator.runAttack({
        attackId: 'A8',
        target: 'NAIVE',
        seed: 301,
        productQuery: 'cable',
        customParams: { mutatedAmountAtomic: '9900000' },
      });

      expect(res.decision).toBe('ALLOW');
      expect(res.attackerWon).toBe(true);
      expect(BigInt(res.funds_lost_atomic)).toBeGreaterThan(0n);
    });

    it('is blocked by BLUE_V1 at Layer L4 Signing Firewall with QUOTE_CHANGED', async () => {
      const res = await orchestrator.runAttack({
        attackId: 'A8',
        target: 'BLUE_V1',
        seed: 302,
        productQuery: 'cable',
        customParams: { mutatedAmountAtomic: '9900000' },
      });

      expect(res.decision).toBe('BLOCK');
      expect(['QUOTE_CHANGED', 'SIGN_UNPINNED']).toContain(res.reason);
      expect(res.layer).toBe('L4');
      expect(res.funds_lost_atomic).toBe('0');
    });
  });

  describe('A18: Approval Bypass with Dummy Token', () => {
    it('bypasses BLUE_V0 because V0 accepts arbitrary non-empty approval strings', async () => {
      const res = await orchestrator.runAttack({
        attackId: 'A18',
        target: 'BLUE_V0',
        seed: 401,
      });

      // Under V0, passing approvalRef: "x-bypass-test" satisfies the naive check
      expect(res.decision).toBe('ALLOW');
    });

    it('is blocked by BLUE_V1 at Layer L3 with APPROVAL_REQUIRED', async () => {
      const res = await orchestrator.runAttack({
        attackId: 'A18',
        target: 'BLUE_V1',
        seed: 402,
      });

      expect(res.decision).toBe('BLOCK');
      expect(res.reason).toBe('APPROVAL_REQUIRED');
      expect(res.layer).toBe('L3');
      expect(res.funds_lost_atomic).toBe('0');
    });
  });
});
