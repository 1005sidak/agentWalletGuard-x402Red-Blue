import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import * as http from 'node:http';
import * as path from 'node:path';
import * as fs from 'node:fs';
import { createConsoleServer } from '../src/console/server';
import { KillSwitch } from '../src/orchestrator/kill-switch';

describe('Phase 7 — Red Console Server & Kill Switch UI', () => {
  let server: http.Server;
  let consoleUrl: string;
  let consoleDb: any;
  let testKillSwitch: KillSwitch;

  const testDir = path.resolve(__dirname, 'test-temp-console');
  const dbPath = path.join(testDir, 'console.db');

  beforeAll(async () => {
    if (fs.existsSync(testDir)) {
      try {
        fs.rmSync(testDir, { recursive: true, force: true });
      } catch {}
    }
    fs.mkdirSync(testDir, { recursive: true });

    testKillSwitch = new KillSwitch();

    // Create a mock orchestrator that simulates attack runs without hitting real network targets
    const mockOrchestrator: any = {
      runAttack: async (opts: any) => {
        testKillSwitch.assertNotKilled();
        return {
          attackId: opts.attackId,
          target: opts.target,
          seed: opts.seed,
          runId: 'test-run-1',
          traceId: 'test-trace-1',
          decision: opts.target === 'NAIVE' ? 'ALLOW' : 'BLOCK',
          reason: opts.target === 'NAIVE' ? 'OK' : 'PAYTO_MISMATCH',
          layer: opts.target === 'NAIVE' ? null : 'L2',
          funds_lost_atomic: opts.target === 'NAIVE' ? '25000000' : '0',
          chain_delta_atomic: '25000000',
          latency_ms: 12.5,
          attackerWon: opts.target === 'NAIVE',
        };
      },
    };

    const consoleApp = createConsoleServer({
      port: 0,
      dbPath,
      killSwitch: testKillSwitch,
      orchestrator: mockOrchestrator,
    });
    consoleDb = consoleApp.db;

    await new Promise<void>((res) => {
      server = consoleApp.app.listen(0, () => {
        const addr: any = server.address();
        consoleUrl = `http://localhost:${addr.port}`;
        res();
      });
    });
  });

  afterAll(async () => {
    server?.close();
    try {
      consoleDb?.close();
    } catch {}
    try {
      if (fs.existsSync(testDir)) {
        fs.rmSync(testDir, { recursive: true, force: true });
      }
    } catch {}
  });

  it('serves Red Console UI on GET / and GET /console', async () => {
    const res = await fetch(`${consoleUrl}/`);
    expect(res.status).toBe(200);
    const html = await res.text();
    expect(html).toContain('ATTACK CONSOLE // RED NODE');
    expect(html).toContain('KILL SWITCH: ARMED');
    expect(html).toContain('18-ATTACK CROSS-TARGET COMPARISON MATRIX');

    const res2 = await fetch(`${consoleUrl}/console`);
    expect(res2.status).toBe(200);
  });

  it('reports status on GET /status', async () => {
    const res = await fetch(`${consoleUrl}/status`);
    expect(res.status).toBe(200);
    const data: any = await res.json();
    expect(data.armed).toBe(true);
    expect(data.killed).toBe(false);
    expect(data.activeAttacksCount).toBe(18);
  });

  it('trips kill switch via POST /kill and reports tripped state', async () => {
    const res = await fetch(`${consoleUrl}/kill`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reason: 'Operator pressed Big Red Button in test' }),
    });
    expect(res.status).toBe(200);
    const data: any = await res.json();
    expect(data.killed).toBe(true);

    const statusRes = await fetch(`${consoleUrl}/status`);
    const statusData: any = await statusRes.json();
    expect(statusData.killed).toBe(true);
    expect(statusData.armed).toBe(false);

    // Verify attack launch is refused while killed
    const attackRes = await fetch(`${consoleUrl}/attack/run`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ attack_id: 'A1', target: 'NAIVE' }),
    });
    expect(attackRes.status).toBe(500);
    const errData: any = await attackRes.json();
    expect(errData.killed).toBe(true);
  });

  it('resets kill switch via POST /reset and allows execution', async () => {
    const resetRes = await fetch(`${consoleUrl}/reset`, { method: 'POST' });
    expect(resetRes.status).toBe(200);
    const resetData: any = await resetRes.json();
    expect(resetData.killed).toBe(false);

    const statusRes = await fetch(`${consoleUrl}/status`);
    const statusData: any = await statusRes.json();
    expect(statusData.killed).toBe(false);
    expect(statusData.armed).toBe(true);
  });

  it('runs single attack, records to database, and updates matrix', async () => {
    const res = await fetch(`${consoleUrl}/attack/run`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        attack_id: 'A1',
        target: 'NAIVE',
        seed: 42,
      }),
    });

    expect(res.status).toBe(200);
    const data: any = await res.json();
    expect(data.success).toBe(true);
    expect(data.result.attackId).toBe('A1');
    expect(data.result.target).toBe('NAIVE');
    expect(data.result.attackerWon).toBe(true);

    // Query GET /matrix
    const matrixRes = await fetch(`${consoleUrl}/matrix`);
    const matrixData: any = await matrixRes.json();
    expect(matrixData.matrix.A1.NAIVE.attempts).toBe(1);
    expect(matrixData.matrix.A1.NAIVE.won).toBe(1);
    expect(matrixData.matrix.A1.NAIVE.fundsLostAtomic).toBe('25000000');
  });

  it('exports CSV and JSON of attack results', async () => {
    // Export JSON
    const jsonRes = await fetch(`${consoleUrl}/export/json`);
    expect(jsonRes.status).toBe(200);
    const jsonData = await jsonRes.json();
    expect(Array.isArray(jsonData)).toBe(true);
    expect(jsonData.length).toBeGreaterThan(0);
    expect(jsonData[0].attack_id).toBe('A1');

    // Export CSV
    const csvRes = await fetch(`${consoleUrl}/export/csv`);
    expect(csvRes.status).toBe(200);
    const csvData = await csvRes.text();
    expect(csvData).toContain('attack_id');
    expect(csvData).toContain('A1');
    expect(csvData).toContain('NAIVE');
  });

  it('clears database via POST /results/reset', async () => {
    const res = await fetch(`${consoleUrl}/results/reset`, { method: 'POST' });
    expect(res.status).toBe(200);

    const matrixRes = await fetch(`${consoleUrl}/matrix`);
    const matrixData: any = await matrixRes.json();
    expect(matrixData.matrix.A1.NAIVE.attempts).toBe(0);
  });
});
