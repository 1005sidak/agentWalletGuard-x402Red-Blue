import { describe, it, expect } from 'vitest';
import { UCB1Bandit } from '../src/learning/bandit';
import { EvolutionaryOptimizer } from '../src/learning/evolution';
import { LearningAgent } from '../src/learning/agent';

describe('Phase 9 — Learning Attacker (UCB1 + (1+λ)-ES)', () => {
  describe('UCB1 Multi-Armed Bandit', () => {
    it('executes cold start by pulling every arm once', () => {
      const arms = ['A1', 'A2', 'A3', 'A4'];
      const bandit = new UCB1Bandit(arms);

      const pulled: string[] = [];
      for (let i = 0; i < arms.length; i++) {
        const arm = bandit.selectArm();
        pulled.push(arm);
        bandit.update(arm, '0');
      }

      expect(pulled.sort()).toEqual(arms.sort());
      expect(bandit.getTotalPulls()).toBe(4);
    });

    it('exploits high-reward arm after cold start', () => {
      const arms = ['A1', 'A2', 'A3'];
      const bandit = new UCB1Bandit(arms, { explorationConstant: 0.2 });

      // Cold start: pull each once
      for (const arm of arms) {
        bandit.selectArm();
        // Give A2 a huge payout (50 TUSD = 50,000,000 atomic), others 0
        if (arm === 'A2') {
          bandit.update(arm, '50000000');
        } else {
          bandit.update(arm, '0');
        }
      }

      // Next 10 pulls should overwhelmingly pick A2 due to high empirical mean reward
      let a2Pulls = 0;
      for (let i = 0; i < 10; i++) {
        const next = bandit.selectArm();
        if (next === 'A2') a2Pulls++;
        bandit.update(next, next === 'A2' ? '50000000' : '0');
      }

      expect(a2Pulls).toBeGreaterThanOrEqual(8);
      expect(bandit.getArm('A2')?.meanReward).toBeCloseTo(1.0, 1);
    });

    it('serializes and deserializes bandit state accurately', () => {
      const bandit = new UCB1Bandit(['A1', 'A2']);
      bandit.update('A1', '25000000');
      bandit.update('A2', '10000000');

      const serialized = bandit.serialize();
      const restored = new UCB1Bandit(['A1', 'A2']);
      restored.deserialize(serialized);

      expect(restored.getTotalPulls()).toBe(2);
      expect(restored.getArm('A1')?.totalReward).toBeCloseTo(0.5, 2);
      expect(restored.getArm('A2')?.totalReward).toBeCloseTo(0.2, 2);
    });
  });

  describe('(1+λ)-ES Evolutionary Strategy', () => {
    it('generates perturbed offspring within specified boundaries', () => {
      const optimizer = new EvolutionaryOptimizer(
        {
          priceMultiplier: { name: 'priceMultiplier', type: 'float', min: 1.0, max: 2.0 },
          delayMs: { name: 'delayMs', type: 'int', min: 0, max: 1000 },
        },
        { priceMultiplier: 1.25, delayMs: 100 },
        { lambda: 6, initialSigma: 0.2 }
      );

      const offspring = optimizer.generateOffspring();
      expect(offspring.length).toBe(6);

      for (const off of offspring) {
        expect(off.priceMultiplier).toBeGreaterThanOrEqual(1.0);
        expect(off.priceMultiplier).toBeLessThanOrEqual(2.0);
        expect(off.delayMs).toBeGreaterThanOrEqual(0);
        expect(off.delayMs).toBeLessThanOrEqual(1000);
      }
    });

    it('replaces parent only when offspring achieves higher reward', () => {
      const optimizer = new EvolutionaryOptimizer(
        { step: { name: 'step', type: 'float', min: 1.0, max: 5.0 } },
        { step: 1.5 }
      );

      expect(optimizer.getParent().reward).toBe(0);

      // Step with better reward
      const res1 = optimizer.step([
        { params: { step: 2.0 }, reward: 0.8 },
        { params: { step: 1.8 }, reward: 0.4 },
      ]);

      expect(res1.parentReplaced).toBe(true);
      expect(optimizer.getParent().params.step).toBe(2.0);
      expect(optimizer.getParent().reward).toBe(0.8);

      // Step with worse reward
      const res2 = optimizer.step([
        { params: { step: 2.5 }, reward: 0.3 },
        { params: { step: 2.2 }, reward: 0.5 },
      ]);

      expect(res2.parentReplaced).toBe(false);
      expect(optimizer.getParent().params.step).toBe(2.0);
    });

    it('adapts sigma according to Rechenberg 1/5th success rule', () => {
      const optimizer = new EvolutionaryOptimizer(
        { val: { name: 'val', type: 'float', min: 0, max: 10 } },
        { val: 1.0 },
        { historyWindow: 5, initialSigma: 0.2, targetSuccessRate: 0.2 }
      );

      const initialSigma = optimizer.getSigma();

      // Simulate 5 consecutive failures (rate = 0 < 0.2)
      for (let i = 0; i < 5; i++) {
        optimizer.step([{ params: { val: 1.1 }, reward: 0 }]);
      }

      // Sigma should decrease to fine-tune
      expect(optimizer.getSigma()).toBeLessThan(initialSigma);
    });
  });

  describe('Learning Agent Integration', () => {
    it('executes learning steps against mock orchestrator', async () => {
      const mockOrchestrator: any = {
        runAttack: async (opts: any) => {
          // If attack is A4, simulate draining 50 TUSD, else defender blocks
          const fundsLost = opts.attackId === 'A4' ? '50000000' : '0';
          return {
            attackId: opts.attackId,
            target: opts.target,
            seed: opts.seed,
            runId: 'learn-run-1',
            traceId: 'learn-trace-1',
            decision: fundsLost > 0 ? 'ALLOW' : 'BLOCK',
            reason: fundsLost > 0 ? 'OK' : 'PAYTO_MISMATCH',
            layer: 'L2',
            funds_lost_atomic: fundsLost,
            chain_delta_atomic: fundsLost,
            latency_ms: 10,
            attackerWon: fundsLost > 0,
          };
        },
      };

      const agent = new LearningAgent({
        orchestrator: mockOrchestrator,
        explorationConstant: 0.5,
      });

      // Run 5 training steps
      const history = await agent.train(5, 'NAIVE');
      expect(history.length).toBe(5);

      for (const h of history) {
        expect(h).toHaveProperty('episode');
        expect(h).toHaveProperty('attackId');
        expect(h).toHaveProperty('reward');
      }

      expect(agent.getBandit().getTotalPulls()).toBe(5);
    });
  });
});
