import * as http from 'node:http';
import * as path from 'node:path';
import * as fs from 'node:fs';
import { createFacilitatorServer } from './facilitator/server';
import { createMerchantServer } from './merchant/server';
import { createConsoleServer } from './console/server';
import { DEFAULT_PORTS } from './contracts/constants';
import { getContractsHash } from './contracts/hash';

const DATA_DIR = path.resolve(__dirname, '../data');

async function main() {
  console.log('\n=================================================================');
  console.log(' ⚔️  RED ATTACKER NODE (LAPTOP 2)');
  console.log('=================================================================');

  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  const contractsHash = getContractsHash().hash;
  console.log(`Contracts Hash: ${contractsHash.slice(0, 16)}...`);

  // Target Blue host (can be set to LAN IP e.g. BLUE_HOST=192.168.1.40)
  const blueHost = process.env.BLUE_HOST || 'localhost';
  const chainUrl = process.env.CHAIN_URL || `http://${blueHost}:${DEFAULT_PORTS.BLUE_CHAIN}`;
  const collectorUrl = process.env.COLLECTOR_URL || `http://${blueHost}:${DEFAULT_PORTS.BLUE_COLLECTOR}`;
  const agentUrl = process.env.AGENT_URL || `http://${blueHost}:${DEFAULT_PORTS.BLUE_AGENT}`;

  const merchantPort = Number(process.env.MERCHANT_PORT) || DEFAULT_PORTS.RED_MERCHANT;
  const facilitatorPort = Number(process.env.FACILITATOR_PORT) || DEFAULT_PORTS.RED_FACILITATOR;
  const consolePort = Number(process.env.CONSOLE_PORT) || DEFAULT_PORTS.RED_CONSOLE;

  const servers: { name: string; port: number; server: http.Server; db?: any }[] = [];

  const cleanup = () => {
    console.log('\n[red] Shutting down Red Attacker services cleanly...');
    for (const s of servers) {
      try {
        s.server.close();
        if (s.db) s.db.close();
        console.log(`  ✓ Stopped ${s.name} (:${s.port})`);
      } catch {}
    }
    process.exit(0);
  };

  process.on('SIGINT', cleanup);
  process.on('SIGTERM', cleanup);

  // 1. Mock Facilitator (:4030)
  const facApp = createFacilitatorServer({
    port: facilitatorPort,
    chainUrl,
  });
  await new Promise<void>((r) => {
    const s = facApp.app.listen(facilitatorPort, '0.0.0.0', () => r());
    servers.push({ name: 'red-facilitator', port: facilitatorPort, server: s });
  });
  console.log(`[1/3] Red Mock Facilitator:    http://localhost:${facilitatorPort}`);

  // 2. Hostile Merchant (:4020)
  const merchantApp = createMerchantServer({
    port: merchantPort,
    facilitatorUrl: `http://localhost:${facilitatorPort}`,
    chainUrl,
  });
  await new Promise<void>((r) => {
    const s = merchantApp.app.listen(merchantPort, '0.0.0.0', () => r());
    servers.push({ name: 'red-merchant', port: merchantPort, server: s });
  });
  console.log(`[2/3] Red Hostile Merchant:    http://localhost:${merchantPort}`);

  // 3. Red Attacker Console (:4060)
  const consoleApp = createConsoleServer({
    port: consolePort,
    dbPath: path.join(DATA_DIR, 'console.db'),
    merchantUrl: `http://localhost:${merchantPort}`,
    facilitatorUrl: `http://localhost:${facilitatorPort}`,
    chainUrl,
    agentUrl,
    collectorUrl,
  });
  await new Promise<void>((r) => {
    const s = consoleApp.app.listen(consolePort, '0.0.0.0', () => r());
    servers.push({ name: 'red-console', port: consolePort, server: s, db: consoleApp.db });
  });
  console.log(`[3/3] Red Attacker Console:    http://localhost:${consolePort}`);

  console.log(`\n  🎯 Target Blue Agent:      ${agentUrl}`);
  console.log(`  ⛓️  Target Blue Blockchain: ${chainUrl}`);
  console.log(`  📡 Target Blue Collector:  ${collectorUrl}`);
  console.log('\n=================================================================');
  console.log(` ⚔️  ATTACKER CONSOLE READY:  http://localhost:${consolePort}`);
  console.log(' Press Ctrl+C to stop.');
  console.log('=================================================================\n');
}

if (require.main === module || (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(__filename))) {
  main().catch((err) => {
    console.error('Fatal Red Node startup error:', err);
    process.exit(1);
  });
}
