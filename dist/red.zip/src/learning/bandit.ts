/**
 * UCB1 (Upper Confidence Bound 1) Multi-Armed Bandit algorithm
 * for selecting the most profitable attack vector among A1–A18.
 *
 * Formula:
 *   Score(i) = \bar{X}_i + c * sqrt((2 * ln(N)) / n_i)
 *
 * Rewards are derived strictly from on-chain funds extracted (funds_lost_atomic).
 */

export interface ArmState {
  id: string;
  pulls: number;
  totalReward: number;
  meanReward: number;
  lastReward: number;
  lastPulledAt?: string;
}

export interface BanditOptions {
  explorationConstant?: number; // c parameter, default sqrt(2) ≈ 1.414
  targetCapAtomic?: number; // Normalization divisor for atomic funds (default 50,000,000 = 50 TUSD)
}

export class UCB1Bandit {
  private arms: Map<string, ArmState> = new Map();
  private totalPulls: number = 0;
  private explorationConstant: number;
  private targetCapAtomic: number;

  constructor(armIds: string[], options: BanditOptions = {}) {
    this.explorationConstant = options.explorationConstant ?? Math.SQRT2;
    this.targetCapAtomic = options.targetCapAtomic ?? 50_000_000;

    for (const id of armIds) {
      this.arms.set(id, {
        id,
        pulls: 0,
        totalReward: 0,
        meanReward: 0,
        lastReward: 0,
      });
    }
  }

  public getArms(): ArmState[] {
    return Array.from(this.arms.values());
  }

  public getArm(id: string): ArmState | undefined {
    return this.arms.get(id);
  }

  public getTotalPulls(): number {
    return this.totalPulls;
  }

  /**
   * Selects the next arm to pull according to UCB1 policy.
   * Pulls each unpulled arm at least once (cold start), then picks highest UCB1 score.
   */
  public selectArm(): string {
    // 1. Cold start: any unpulled arm has infinite priority
    for (const [id, arm] of this.arms.entries()) {
      if (arm.pulls === 0) {
        return id;
      }
    }

    // 2. Compute UCB1 score for each arm
    let bestArmId: string | null = null;
    let highestScore = -Infinity;

    const lnN = Math.log(this.totalPulls);

    for (const [id, arm] of this.arms.entries()) {
      const exploitation = arm.meanReward;
      const exploration = this.explorationConstant * Math.sqrt((2 * lnN) / arm.pulls);
      const score = exploitation + exploration;

      if (score > highestScore) {
        highestScore = score;
        bestArmId = id;
      }
    }

    return bestArmId || this.arms.keys().next().value!;
  }

  /**
   * Updates arm state with the observed on-chain reward.
   * Reward is normalized into [0.0, 1.0] based on targetCapAtomic.
   */
  public update(armId: string, fundsLostAtomic: string | bigint | number): number {
    const arm = this.arms.get(armId);
    if (!arm) {
      throw new Error(`Unknown arm ID: ${armId}`);
    }

    const fundsBigInt = BigInt(fundsLostAtomic.toString());
    const normalizedReward =
      fundsBigInt > 0n
        ? Math.min(1.0, Number(fundsBigInt) / this.targetCapAtomic)
        : 0.0;

    arm.pulls += 1;
    arm.totalReward += normalizedReward;
    arm.meanReward = arm.totalReward / arm.pulls;
    arm.lastReward = normalizedReward;
    arm.lastPulledAt = new Date().toISOString();

    this.totalPulls += 1;

    return normalizedReward;
  }

  /**
   * Serializes bandit state for storage or persistence.
   */
  public serialize(): { totalPulls: number; arms: ArmState[] } {
    return {
      totalPulls: this.totalPulls,
      arms: Array.from(this.arms.values()),
    };
  }

  /**
   * Restores bandit state.
   */
  public deserialize(state: { totalPulls: number; arms: ArmState[] }): void {
    this.totalPulls = state.totalPulls;
    for (const a of state.arms) {
      this.arms.set(a.id, { ...a });
    }
  }
}
