/**
 * (1+λ)-ES (Evolutionary Strategy) for optimizing attack parameters.
 *
 * Implements Rechenberg's 1/5th success rule to dynamically tune the
 * mutation step size sigma based on reward feedback.
 */

export interface ParameterSpec {
  name: string;
  type: 'float' | 'int' | 'choice';
  min?: number;
  max?: number;
  choices?: (string | number)[];
  step?: number;
}

export interface Individual {
  params: Record<string, any>;
  reward: number;
  generation: number;
}

export interface EvolutionaryOptions {
  lambda?: number; // Offspring count per generation (default: 4)
  initialSigma?: number; // Initial mutation strength (default: 0.1)
  targetSuccessRate?: number; // 1/5th rule threshold (default: 0.20)
  historyWindow?: number; // Generations tracked for 1/5th rule adaptation (default: 10)
}

export class EvolutionaryOptimizer {
  private specs: Record<string, ParameterSpec>;
  private lambda: number;
  private sigma: number;
  private targetSuccessRate: number;
  private historyWindow: number;

  private parent: Individual;
  private currentGeneration: number = 0;
  private successHistory: boolean[] = [];

  constructor(
    specs: Record<string, ParameterSpec>,
    initialParams: Record<string, any>,
    options: EvolutionaryOptions = {}
  ) {
    this.specs = specs;
    this.lambda = options.lambda ?? 4;
    this.sigma = options.initialSigma ?? 0.1;
    this.targetSuccessRate = options.targetSuccessRate ?? 0.2;
    this.historyWindow = options.historyWindow ?? 10;

    this.parent = {
      params: { ...initialParams },
      reward: 0,
      generation: 0,
    };
  }

  public getParent(): Individual {
    return { ...this.parent, params: { ...this.parent.params } };
  }

  public getSigma(): number {
    return this.sigma;
  }

  public getGeneration(): number {
    return this.currentGeneration;
  }

  /**
   * Generates lambda mutated offspring from the current parent.
   */
  public generateOffspring(): Record<string, any>[] {
    const offspring: Record<string, any>[] = [];

    for (let i = 0; i < this.lambda; i++) {
      const candidate: Record<string, any> = {};

      for (const [key, spec] of Object.entries(this.specs)) {
        const parentVal = this.parent.params[key];

        if (spec.type === 'float') {
          // Gaussian-like perturbation: step * sigma * Box-Muller sample
          const u1 = Math.random() || 0.0001;
          const u2 = Math.random();
          const gaussian = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
          const range = (spec.max ?? 2.0) - (spec.min ?? 0.0);
          let newVal = parentVal + gaussian * this.sigma * range * 0.2;

          if (spec.min !== undefined) newVal = Math.max(spec.min, newVal);
          if (spec.max !== undefined) newVal = Math.min(spec.max, newVal);
          candidate[key] = Number(newVal.toFixed(4));
        } else if (spec.type === 'int') {
          const delta = Math.round((Math.random() - 0.5) * 4 * Math.max(1, this.sigma * 5));
          let newVal = parentVal + delta;
          if (spec.min !== undefined) newVal = Math.max(spec.min, newVal);
          if (spec.max !== undefined) newVal = Math.min(spec.max, newVal);
          candidate[key] = Math.round(newVal);
        } else if (spec.type === 'choice' && spec.choices) {
          if (Math.random() < this.sigma) {
            candidate[key] = spec.choices[Math.floor(Math.random() * spec.choices.length)];
          } else {
            candidate[key] = parentVal;
          }
        } else {
          candidate[key] = parentVal;
        }
      }

      offspring.push(candidate);
    }

    return offspring;
  }

  /**
   * Evaluates offspring and applies (1+λ) selection and 1/5th rule adaptation.
   */
  public step(evaluatedOffspring: Array<{ params: Record<string, any>; reward: number }>): {
    parentReplaced: boolean;
    parentReward: number;
    sigma: number;
  } {
    this.currentGeneration++;

    // Find best offspring
    let bestOffspring = evaluatedOffspring[0];
    for (const off of evaluatedOffspring) {
      if (off.reward > bestOffspring.reward) {
        bestOffspring = off;
      }
    }

    // (1+λ) Selection: offspring replaces parent if strictly better or equal
    let parentReplaced = false;
    if (bestOffspring && bestOffspring.reward >= this.parent.reward && bestOffspring.reward > 0) {
      this.parent = {
        params: { ...bestOffspring.params },
        reward: bestOffspring.reward,
        generation: this.currentGeneration,
      };
      parentReplaced = true;
    }

    // Record success for 1/5th rule
    this.successHistory.push(parentReplaced);
    if (this.successHistory.length > this.historyWindow) {
      this.successHistory.shift();
    }

    // Adapt sigma via Rechenberg's 1/5 rule
    if (this.successHistory.length >= this.historyWindow) {
      const successes = this.successHistory.filter(Boolean).length;
      const rate = successes / this.successHistory.length;

      if (rate > this.targetSuccessRate) {
        // High success: increase step size to explore wider landscape
        this.sigma = Math.min(1.0, this.sigma * 1.22);
      } else if (rate < this.targetSuccessRate) {
        // Low success: decrease step size to fine-tune around peak
        this.sigma = Math.max(0.01, this.sigma * 0.82);
      }
    }

    return {
      parentReplaced,
      parentReward: this.parent.reward,
      sigma: this.sigma,
    };
  }
}
