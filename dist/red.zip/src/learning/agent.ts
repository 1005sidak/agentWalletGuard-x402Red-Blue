import { UCB1Bandit } from './bandit';
import { EvolutionaryOptimizer } from './evolution';
import { AttackOrchestrator } from '../orchestrator/runner';
import { ATTACK_IDS, ATTACKS_CATALOG } from '../contracts/attacks';
import { TargetMode } from '../contracts/events';

export interface LearningAgentConfig {
  orchestrator: AttackOrchestrator;
  explorationConstant?: number;
  targetCapAtomic?: number;
}

export class LearningAgent {
  private orchestrator: AttackOrchestrator;
  private bandit: UCB1Bandit;
  private optimizers: Map<string, EvolutionaryOptimizer> = new Map();

  constructor(config: LearningAgentConfig) {
    this.orchestrator = config.orchestrator;
    this.bandit = new UCB1Bandit(ATTACK_IDS, {
      explorationConstant: config.explorationConstant,
      targetCapAtomic: config.targetCapAtomic,
    });

    // Initialize evolutionary parameter optimizers for parameter-sensitive attacks
    // A3: Price creep
    this.optimizers.set(
      'A3',
      new EvolutionaryOptimizer(
        {
          stepMultiplier: { name: 'stepMultiplier', type: 'float', min: 1.01, max: 2.0 },
        },
        { stepMultiplier: 1.25 }
      )
    );

    // A7: Burst race
    this.optimizers.set(
      'A7',
      new EvolutionaryOptimizer(
        {
          concurrency: { name: 'concurrency', type: 'int', min: 5, max: 50 },
        },
        { concurrency: 20 }
      )
    );

    // A11: Slow drain
    this.optimizers.set(
      'A11',
      new EvolutionaryOptimizer(
        {
          intervalMs: { name: 'intervalMs', type: 'int', min: 50, max: 500 },
        },
        { intervalMs: 200 }
      )
    );
  }

  public getBandit(): UCB1Bandit {
    return this.bandit;
  }

  public getOptimizer(attackId: string): EvolutionaryOptimizer | undefined {
    return this.optimizers.get(attackId);
  }

  /**
   * Executes one learning step against the specified target mode:
   * 1. Bandit selects attack arm
   * 2. Evolutionary optimizer mutates continuous parameters (if applicable)
   * 3. Orchestrator executes attack
   * 4. Chain balance delta reward updates bandit and evolutionary models
   */
  public async step(target: TargetMode = 'BLUE_V1', seed?: number): Promise<{
    attackId: string;
    target: TargetMode;
    decision: 'ALLOW' | 'BLOCK';
    fundsLostAtomic: string;
    reward: number;
    attackerWon: boolean;
  }> {
    const attackId = this.bandit.selectArm();
    const actualSeed = seed ?? Date.now();

    let customParams: Record<string, any> = {};
    const opt = this.optimizers.get(attackId);
    let candidateParams: Record<string, any> | null = null;

    if (opt) {
      const offspring = opt.generateOffspring();
      candidateParams = offspring[0];
      customParams = { ...candidateParams };
    }

    const result = await this.orchestrator.runAttack({
      attackId,
      target,
      seed: actualSeed,
      customParams,
    });

    const reward = this.bandit.update(attackId, result.funds_lost_atomic);

    if (opt && candidateParams) {
      opt.step([{ params: candidateParams, reward }]);
    }

    return {
      attackId,
      target,
      decision: result.decision,
      fundsLostAtomic: result.funds_lost_atomic,
      reward,
      attackerWon: result.attackerWon,
    };
  }

  /**
   * Runs multiple sequential learning episodes.
   */
  public async train(
    episodes: number,
    target: TargetMode = 'BLUE_V1'
  ): Promise<
    Array<{
      episode: number;
      attackId: string;
      reward: number;
      fundsLostAtomic: string;
    }>
  > {
    const history = [];

    for (let i = 0; i < episodes; i++) {
      const stepRes = await this.step(target, 1000 + i);
      history.push({
        episode: i + 1,
        attackId: stepRes.attackId,
        reward: stepRes.reward,
        fundsLostAtomic: stepRes.fundsLostAtomic,
      });
    }

    return history;
  }
}
