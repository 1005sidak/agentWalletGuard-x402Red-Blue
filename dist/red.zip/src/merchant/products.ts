import { Product } from '../contracts/api';

export const CATALOG: Record<string, Product> = {
  mouse: {
    id: 'mouse',
    name: 'Ergonomic Wireless Mouse',
    category: 'Peripherals',
    description: 'Precision wireless mouse with optical tracking and ergonomic grip.',
    price_atomic: '25000000', // 25.00 TUSD
    price_display_inr: '₹2,125.00',
    currency: 'TUSD',
    stock: 50,
    image_url: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400',
  },
  keyboard: {
    id: 'keyboard',
    name: 'Mechanical Gaming Keyboard',
    category: 'Peripherals',
    description: 'Tactile mechanical keyboard with hot-swappable switches and RGB backlight.',
    price_atomic: '65000000', // 65.00 TUSD
    price_display_inr: '₹5,525.00',
    currency: 'TUSD',
    stock: 30,
    image_url: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=400',
  },
  cable: {
    id: 'cable',
    name: 'Braided USB-C Cable (2m)',
    category: 'Cables',
    description: 'High-speed 100W PD charging and 10Gbps data sync cable.',
    price_atomic: '5000000', // 5.00 TUSD
    price_display_inr: '₹425.00',
    currency: 'TUSD',
    stock: 120,
    image_url: 'https://images.unsplash.com/photo-1609081219090-a6d81d3085bf?w=400',
  },
  stand: {
    id: 'stand',
    name: 'Aluminum Laptop Stand',
    category: 'Accessories',
    description: 'Foldable ergonomic aluminum stand with heat dissipation vents.',
    price_atomic: '30000000', // 30.00 TUSD
    price_display_inr: '₹2,550.00',
    currency: 'TUSD',
    stock: 45,
    image_url: 'https://images.unsplash.com/photo-1544816155-12df9643f363?w=400',
  },
  headphones: {
    id: 'headphones',
    name: 'Noise Cancelling Headphones',
    category: 'Audio',
    description: 'Wireless over-ear headphones with active noise cancellation.',
    price_atomic: '80000000', // 80.00 TUSD
    price_display_inr: '₹6,800.00',
    currency: 'TUSD',
    stock: 25,
    image_url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400',
  },
  monitor: {
    id: 'monitor',
    name: '27-inch 4K IPS Monitor',
    category: 'Displays',
    description: 'Ultra HD 4K color-accurate IPS display with HDR400 and USB-C hub.',
    price_atomic: '250000000', // 250.00 TUSD
    price_display_inr: '₹21,250.00',
    currency: 'TUSD',
    stock: 10,
    image_url: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=400',
  },
};
