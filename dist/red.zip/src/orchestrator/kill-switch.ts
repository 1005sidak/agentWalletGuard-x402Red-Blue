/**
 * Thread-safe real-time Kill Switch for Red Orchestrator and attack workers.
 * When engaged, immediately halts all running and queued attack sequences.
 */
export class KillSwitch {
  private killed = false;
  private reason: string | null = null;
  private killedAt: string | null = null;

  public isKilled(): boolean {
    return this.killed;
  }

  public kill(reason: string = 'User initiated kill switch'): void {
    this.killed = true;
    this.reason = reason;
    this.killedAt = new Date().toISOString();
  }

  public trip(reason: string = 'User initiated kill switch'): void {
    this.kill(reason);
  }

  public getReason(): string | null {
    return this.reason;
  }

  public reset(): void {
    this.killed = false;
    this.reason = null;
    this.killedAt = null;
  }

  public getStatus() {
    return {
      killed: this.killed,
      reason: this.reason,
      killed_at: this.killedAt,
    };
  }

  public assertNotKilled(): void {
    if (this.killed) {
      throw new Error(`Attack sequence aborted by Red Kill Switch: ${this.reason || 'Killed'}`);
    }
  }
}

export const globalKillSwitch = new KillSwitch();
