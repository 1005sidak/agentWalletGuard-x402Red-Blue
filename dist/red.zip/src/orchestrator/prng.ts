/**
 * Deterministic 32-bit Mulberry32 seeded Pseudo-Random Number Generator.
 * Guarantees 100% reproducible test and attack sequences across platforms.
 */
export interface SeededRng {
  next(): number; // [0, 1)
  nextInt(min: number, max: number): number; // inclusive [min, max]
  pick<T>(arr: T[]): T;
  seed: number;
}

export function createSeededRng(seed: number): SeededRng {
  let s = Math.floor(seed) >>> 0;

  function next(): number {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  return {
    seed,
    next,
    nextInt(min: number, max: number): number {
      const lo = Math.ceil(min);
      const hi = Math.floor(max);
      return Math.floor(next() * (hi - lo + 1)) + lo;
    },
    pick<T>(arr: T[]): T {
      if (arr.length === 0) throw new Error('Cannot pick from empty array');
      const idx = Math.floor(next() * arr.length);
      return arr[idx];
    },
  };
}
