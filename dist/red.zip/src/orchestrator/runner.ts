import * as crypto from 'node:crypto';
import { TargetMode, SecurityEvent } from '../contracts/events';
import { ATTACKS_CATALOG } from '../contracts/attacks';
import { KillSwitch, globalKillSwitch } from './kill-switch';
import { createSeededRng } from './prng';

export interface OrchestratorConfig {
  merchantUrl?: string;
  facilitatorUrl?: string;
  chainUrl?: string;
  agentUrl?: string;
  collectorUrl?: string;
  attackerPayTo?: string;
  agentAddress?: string;
  killSwitch?: KillSwitch;
}

export interface AttackExecutionOptions {
  attackId: string;
  target: TargetMode;
  seed: number;
  runId?: string;
  traceId?: string;
  customParams?: Record<string, unknown>;
  productQuery?: string;
  quantity?: number;
}

export interface AttackExecutionResult {
  attackId: string;
  target: TargetMode;
  seed: number;
  runId: string;
  traceId: string;
  decision: 'ALLOW' | 'BLOCK';
  reason: string | null;
  layer: string | null;
  funds_lost_atomic: string;
  chain_delta_atomic: string;
  latency_ms: number;
  attackerWon: boolean; // true if funds were diverted/stolen
}

export class AttackOrchestrator {
  private merchantUrl: string;
  private facilitatorUrl: string;
  private chainUrl: string;
  private agentUrl: string;
  private collectorUrl: string;
  private attackerPayTo: string;
  private agentAddress: string;
  private killSwitch: KillSwitch;

  constructor(config: OrchestratorConfig = {}) {
    this.merchantUrl = config.merchantUrl || process.env.MERCHANT_URL || 'http://localhost:4020';
    this.facilitatorUrl = config.facilitatorUrl || process.env.FACILITATOR_URL || 'http://localhost:4030';
    this.chainUrl = config.chainUrl || process.env.CHAIN_URL || 'http://localhost:4040';
    this.agentUrl = config.agentUrl || process.env.AGENT_URL || 'http://localhost:4010';
    this.collectorUrl = config.collectorUrl || process.env.COLLECTOR_URL || 'http://localhost:4050';
    this.attackerPayTo = (config.attackerPayTo || process.env.ATTACKER_PAYTO || '0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC').toLowerCase();
    this.agentAddress = (config.agentAddress || process.env.AGENT_ADDRESS || '').toLowerCase();
    this.killSwitch = config.killSwitch || globalKillSwitch;
  }

  private async getChainBalance(address: string): Promise<bigint> {
    try {
      const res = await fetch(`${this.chainUrl}/balances?address=${address.toLowerCase()}`);
      if (!res.ok) return 0n;
      const data: any = await res.json();
      return BigInt(data.balance_atomic || '0');
    } catch {
      return 0n;
    }
  }

  public async runAttack(opts: AttackExecutionOptions): Promise<AttackExecutionResult> {
    this.killSwitch.assertNotKilled();

    const startMs = Date.now();
    const runId = opts.runId || 'run-' + crypto.randomUUID().slice(0, 8);
    const traceId = opts.traceId || 'trace-' + crypto.randomUUID().slice(0, 8);
    const attackMeta = ATTACKS_CATALOG[opts.attackId] || {
      id: opts.attackId,
      name: 'Custom Attack',
      defaultParams: {},
    };

    const mergedParams = {
      ...attackMeta.defaultParams,
      ...(opts.customParams || {}),
    };

    // 1. Initial on-chain balances
    const initialAttackerBal = await this.getChainBalance(this.attackerPayTo);

    // 2. Configure Blue Agent Mode
    await fetch(`${this.agentUrl}/control/mode`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode: opts.target }),
    });

    // 3. Set up attack hooks & modes
    if (opts.attackId === 'A8') {
      await fetch(`${this.agentUrl}/control/test-hook/quote-mutation`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enabled: true,
          mutatedAmountAtomic: mergedParams.mutatedAmountAtomic || '9900000',
        }),
      });
    }

    if (opts.attackId === 'A16') {
      await fetch(`${this.facilitatorUrl}/facilitator/mode`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: 'PHANTOM_SUCCESS' }),
      });
    } else if (opts.attackId === 'A17') {
      await fetch(`${this.facilitatorUrl}/facilitator/mode`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: 'SETTLE_AND_FAIL' }),
      });
    }

    await fetch(`${this.merchantUrl}/attack/mode`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: opts.attackId, params: mergedParams }),
    });

    let purchaseResult: any = null;

    try {
      this.killSwitch.assertNotKilled();

      // 4. Trigger Purchase
      if (opts.attackId === 'A7') {
        // Parallel burst race: 20 simultaneous concurrent calls
        const burstPromises = Array.from({ length: 20 }, (_, idx) =>
          fetch(`${this.agentUrl}/control/purchase`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              run_id: runId,
              trace_id: `${traceId}-burst-${idx}`,
              seed: opts.seed,
              intent: {
                product_query: opts.productQuery || 'mouse',
                quantity: 1,
                max_total_atomic: '10000000',
              },
              auto_confirm: true,
              attack_id: opts.attackId,
            }),
          }).then((r) => r.json())
        );

        const burstResults = await Promise.all(burstPromises);
        purchaseResult = burstResults[0];
      } else {
        const pRes = await fetch(`${this.agentUrl}/control/purchase`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            run_id: runId,
            trace_id: traceId,
            seed: opts.seed,
            intent: {
              product_query: opts.productQuery || 'mouse',
              quantity: opts.quantity || 1,
              max_total_atomic: '50000000',
            },
            auto_confirm: opts.attackId === 'A18' ? false : true,
            attack_id: opts.attackId,
          }),
        });
        purchaseResult = await pRes.json();
      }
    } finally {
      // 5. Clean up attack states back to honest
      await fetch(`${this.merchantUrl}/attack/mode`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: 'HONEST' }),
      }).catch(() => {});

      await fetch(`${this.facilitatorUrl}/facilitator/mode`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: 'NONE' }),
      }).catch(() => {});

      if (opts.attackId === 'A8') {
        await fetch(`${this.agentUrl}/control/test-hook/quote-mutation`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ enabled: false }),
        }).catch(() => {});
      }
    }

    // 6. Final on-chain balances
    const finalAttackerBal = await this.getChainBalance(this.attackerPayTo);
    const attackerDelta = finalAttackerBal - initialAttackerBal;
    const chainDelta = purchaseResult?.chain_delta_atomic || '0';
    let fundsLost = attackerDelta > 0n ? attackerDelta.toString() : '0';

    // In A8 quote mutation, funds lost is the excess amount debited beyond the intended price
    if (opts.attackId === 'A8' && BigInt(chainDelta) > 5000000n) {
      fundsLost = (BigInt(chainDelta) - 5000000n).toString();
    }

    const latency = Date.now() - startMs;
    const decision = purchaseResult?.decision || (BigInt(fundsLost) > 0n ? 'ALLOW' : 'BLOCK');
    const reason = purchaseResult?.reason || (decision === 'ALLOW' ? 'OK' : 'ATTACK_BLOCKED');
    const layer = purchaseResult?.layer || null;

    // 7. Emit Red perspective event to collector
    const redEvent: SecurityEvent = {
      event_id: crypto.randomUUID(),
      run_id: runId,
      trace_id: traceId,
      worker: 'red-orchestrator',
      attack: opts.attackId,
      seed: opts.seed,
      target: opts.target,
      decision: decision as any,
      reason: reason as any,
      layer: layer as any,
      pin_hash: null,
      amount_atomic: purchaseResult?.order_result?.total_atomic || null,
      chain_delta_atomic: chainDelta,
      funds_lost_atomic: fundsLost,
      latency_ms: latency,
      policy_digest: null,
      ts: new Date().toISOString(),
      details: {
        attackName: attackMeta.name,
        params: mergedParams,
        attackerWon: BigInt(fundsLost) > 0n,
      },
    };

    fetch(`${this.collectorUrl}/events`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(redEvent),
    }).catch(() => {});

    return {
      attackId: opts.attackId,
      target: opts.target,
      seed: opts.seed,
      runId,
      traceId,
      decision,
      reason,
      layer,
      funds_lost_atomic: fundsLost,
      chain_delta_atomic: chainDelta,
      latency_ms: latency,
      attackerWon: BigInt(fundsLost) > 0n,
    };
  }
}
