import * as fc from 'fast-check';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { arbitrary402Body } from './generator';
import { mutate402Response, ALL_MUTATIONS } from './mutator';

export interface FuzzRunOptions {
  numRuns?: number;
  seed?: number;
  regressionsDir?: string;
  onIteration?: (index: number, result: 'PASSED' | 'BLOCKED' | 'FAILED') => void;
}

export interface FuzzReport {
  totalRuns: number;
  blockedCount: number;
  allowedCount: number;
  invariantsViolated: number;
  failingInputs: Array<{
    payload: any;
    violation: string;
    error?: string;
  }>;
}

export class FuzzRunner {
  private regressionsDir: string;

  constructor(options: { regressionsDir?: string } = {}) {
    this.regressionsDir =
      options.regressionsDir || path.resolve(__dirname, '../../tests/regressions');
    if (!fs.existsSync(this.regressionsDir)) {
      try {
        fs.mkdirSync(this.regressionsDir, { recursive: true });
      } catch {}
    }
  }

  /**
   * Runs property-based fuzz tests against a target 402 evaluation handler.
   * Tests the universal fail-closed invariant:
   * Guard MUST never throw an unhandled exception or crash the process.
   * If evaluated, it must return { allowed: false, reason: string } or throw GuardBlockError.
   */
  public async fuzzFailClosed(
    evaluate402: (raw402Body: any) => Promise<{ allowed: boolean; reason?: string }>,
    options: FuzzRunOptions = {}
  ): Promise<FuzzReport> {
    const numRuns = options.numRuns || 100;
    const seed = options.seed || 1337;
    let blockedCount = 0;
    let allowedCount = 0;
    let invariantsViolated = 0;
    const failingInputs: FuzzReport['failingInputs'] = [];

    let count = 0;
    try {
      await fc.assert(
        fc.asyncProperty(arbitrary402Body, async (body) => {
          count++;
          try {
            const res = await evaluate402(body);
            if (res.allowed) {
              allowedCount++;
              // If allowed, verify it meets basic validity (at least 1 requirement exists)
              if (!body.accepts || body.accepts.length === 0) {
                invariantsViolated++;
                failingInputs.push({
                  payload: body,
                  violation: 'ALLOWED_EMPTY_ACCEPTS',
                });
                return false;
              }
            } else {
              blockedCount++;
              if (!res.reason) {
                invariantsViolated++;
                failingInputs.push({
                  payload: body,
                  violation: 'BLOCKED_WITHOUT_REASON',
                });
                return false;
              }
            }
          } catch (err: any) {
            // If it throws, check if it was a caught/expected GuardBlockError
            if (err.name === 'GuardBlockError' || err.code) {
              blockedCount++;
            } else {
              // Unhandled runtime crash = fail-closed invariant violation!
              invariantsViolated++;
              failingInputs.push({
                payload: body,
                violation: 'UNHANDLED_CRASH',
                error: err.stack || err.message,
              });
              return false;
            }
          }
          return true;
        }),
        {
          numRuns,
          seed,
          endOnFailure: false,
        }
      );
    } catch {
      // fc.assert throws on property failure
    }

    return {
      totalRuns: count,
      blockedCount,
      allowedCount,
      invariantsViolated,
      failingInputs,
    };
  }

  /**
   * Saves a minimal reproducible failing input into the regressions directory.
   */
  public exportRegression(name: string, payload: any, violation: string, error?: string): string {
    const filename = `${name}-${Date.now()}.json`;
    const filepath = path.join(this.regressionsDir, filename);
    const content = JSON.stringify(
      {
        name,
        violation,
        error,
        timestamp: new Date().toISOString(),
        payload,
      },
      null,
      2
    );

    fs.writeFileSync(filepath, content, 'utf-8');
    return filepath;
  }

  /**
   * Loads all saved regression test cases from the regressions folder.
   */
  public loadRegressions(): Array<{ name: string; violation: string; payload: any }> {
    if (!fs.existsSync(this.regressionsDir)) return [];
    const files = fs.readdirSync(this.regressionsDir).filter((f) => f.endsWith('.json'));
    return files.map((f) => {
      const raw = fs.readFileSync(path.join(this.regressionsDir, f), 'utf-8');
      return JSON.parse(raw);
    });
  }
}
